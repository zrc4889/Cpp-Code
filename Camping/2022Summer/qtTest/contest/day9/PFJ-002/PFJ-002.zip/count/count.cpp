#include <bits/stdc++.h>
using namespace std;
int main()
{
    // DFS 暴力哼哼哼哈哈哈哈
    /*XYC YYDS*/
    /*cookiebus YYDS
    /*nullptr YYDS*/
    /*tree_one_ YYDS*/
    /*PinkRabbit YYDS*/
    /*Eternity YYDS*/
    /*yuxinhao YYDS*/
    /*_ YYDS*/

    return 0;
}