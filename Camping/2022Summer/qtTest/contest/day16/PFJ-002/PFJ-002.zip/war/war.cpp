#include <bits/stdc++.h>
using namespace std;

int main()
{
    // #ifdef LOCAL
    // LOCALfo
    // #endif
    // #endif
    int n;
    cin >> n;
    for (int i = 1; i <= n; i++)
    {
        cin >> a[i];
    }
    
    return 0;
}