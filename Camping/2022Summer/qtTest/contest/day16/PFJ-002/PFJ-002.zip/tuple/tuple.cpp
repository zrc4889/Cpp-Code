#include <bits/stdc++.h>
using namespace std;
// 容斥原理？
int main()
{
    // #ifdef LOCAL
    // LOCALfo
    // #endif
    freopen("tuple.in", "r", stdin);
    freopen("tuple.out", "w", stdout);
    int n;
    cin >> n;
    long long ans = 0;
    for (int a = 1; a <= n; a++)
    {
        for (int b = a; b <= n; b += a)
        {
            for (int c = b; c <= n; c += b)
            {
                if (a != b && b != c && a != c)
                    ans++;
            }
        }
    }
    cout << ans << endl;
    return 0;
}