#include <bits/stdc++.h>
using namespace std;
const int _ = 1e4 + 10;
int a[_];
int main()
{
    // #ifdef LOCAL
    //     LOCALfo
    // #endif
    // 要不然一直右移，要不然一直左移
    freopen("sort.in", "r", stdin);
    freopen("sort.out", "w", stdout);
    int n;
    int L, R;
    cin >> n;
    for (int i = 1; i <= n; i++)
        cin >> a[i];
    cin >> L >> R;
    int t = n;
    int ans1 = 0, ans2 = 0;

    for (int i = 1; i < n; i++)
    {
        if (a[i + 1] < a[i])
        {
            ans1 += R;
            ans2 += (n - i) * L;
        }
    }
    cout << min(ans1, ans2);
    return 0;
}