#include<cstdio>
#include<cstring>
#include<vector>
using namespace std;
inline int read()
{
	int x;char c;
	while((c=getchar())<'0'||c>'9');
	for(x=c-'0';(c=getchar())>='0'&&c<='9';)x=x*10+c-'0';
	return x;
}
#define MN 100000
int a[MN+5],b[MN+5],x[MN+5],y[MN+5],z[MN+5],l[MN+5],r[MN+5],ans[MN+5],f[MN+5],s[MN+5];
vector<int> v[MN+5];
int gf(int k){return f[k]?f[k]=gf(f[k]):k;}
int main()
{
	freopen("explore.in","r",stdin);
	freopen("explore.out","w",stdout);
	int n,m,q,i,j,o,X,Y;
	n=read();m=read();
	for(i=1;i<=m;++i)a[i]=read(),b[i]=read();
	for(q=read(),i=1;i<=q;++i)x[i]=read(),y[i]=read(),z[i]=read(),l[i]=1,r[i]=m;
	while(true)
	{
		for(i=1;i<=m;++i)v[i].clear();
		for(i=o=1;i<=q;++i)if(l[i]<=r[i])
			o=0,v[l[i]+r[i]>>1].push_back(i);
		if(o)break;
		for(i=1;i<=n;++i)f[i]=0,s[i]=1;
		for(i=1;i<=m;++i)
		{
			if(gf(a[i])!=gf(b[i]))s[gf(a[i])]+=s[gf(b[i])],f[gf(b[i])]=gf(a[i]);
			for(j=0;j<v[i].size();++j)
			{
				X=gf(x[v[i][j]]);Y=gf(y[v[i][j]]);
				if((X^Y?s[X]+s[Y]:s[X])>=z[v[i][j]])ans[v[i][j]]=i,r[v[i][j]]=i-1;
				else l[v[i][j]]=i+1;
			}
		}
	}
	for(i=1;i<=q;++i)printf("%d\n",ans[i]);
}
