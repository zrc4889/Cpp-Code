#include<cstdio>
int main()
{
	freopen("subset.in","r",stdin);
	freopen("subset.out","w",stdout);
	long long a,b,i,j;
	scanf("%lld%lld",&a,&b);
	if(a==b)return 0*puts("1");
	for(i=59;(a>>i)==(b>>i);--i);
	a&=(1LL<<i)-1;b&=(1LL<<i)-1;
	for(j=i;j--;)if(b&(1LL<<j)){b=(1LL<<j+1)-1;break;}
	printf("%lld",(1LL<<i)-a+(b<a?(1LL<<i)-a+b+1:1LL<<i));
}
