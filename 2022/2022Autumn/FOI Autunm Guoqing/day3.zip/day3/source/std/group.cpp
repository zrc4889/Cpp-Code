#include<cstdio>
inline int read()
{
	int x;char c;
	while((c=getchar())<'0'||c>'9');
	for(x=c-'0';(c=getchar())>='0'&&c<='9';)x=x*10+c-'0';
	return x;
}
#define MN 1000
int a[MN+5][MN+5],l[MN+5],u[MN+5],s[MN+5];
int main()
{
	freopen("group.in","r",stdin);
	freopen("group.out","w",stdout);
	int n,m,i,j,ans;
	ans=n=read();m=read();
	for(i=1;i<=n;++i)for(j=1;j<=m;++j)a[i][j]=read();
	for(i=1;i<=n;++i)++s[a[i][l[i]=1]];
	while(true)
	{
		for(i=j=1;i<=m;++i)if(s[i]>s[j])j=i;
		if(s[j]<ans)ans=s[j];
		for(u[j]=i=1;i<=n;++i)
		{
			while(l[i]<=m&&u[a[i][l[i]]])
				--s[a[i][l[i]]],++s[a[i][++l[i]]];
			if(l[i]>m)return 0*printf("%d",ans);
		}
	}
}
