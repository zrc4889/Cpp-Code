#include <bits/stdc++.h>
using namespace std;

int main() {
#ifdef LOCAL
    LOCALfo
#endif
    ;
return 0;
}