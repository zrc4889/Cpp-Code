#include <bits/stdc++.h>
using namespace std;

int main()
{
    // #ifdef LOCAL
    // LOCALfo
    // #endif
    freopen("wa.in", "r", stdin);
    freopen("wa.out", "w", stdout);
    // 最小生成树
    // 换根dp
    return 0;
}