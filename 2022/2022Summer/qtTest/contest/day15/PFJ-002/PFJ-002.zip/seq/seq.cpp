#include <bits/stdc++.h>
using namespace std;
const int _ = 1e3 + 10;
int a[_], f[_];
int main()
{
    // #ifdef LOCAL
    //     LOCALfo
    // #endif
    freopen("seq.in", "r", stdin);
    freopen("seq.out", "w", stdout);
    int n;
    cin >> n;
    for (int i = 1; i <= n; i++)
        cin >> a[i];
    
    return 0;
}