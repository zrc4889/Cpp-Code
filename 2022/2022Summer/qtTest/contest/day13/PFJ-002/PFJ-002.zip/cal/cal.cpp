#include <bits/stdc++.h>
using namespace std;
int a[] = {0, 1, 2, 2, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5};
int main()
{
    freopen("cal.in","r",stdin);
    freopen("cal.out","w",stdout);
    // 预计30pts
    int n;
    cin >> n;
    cout << a[n];
    return 0;
}