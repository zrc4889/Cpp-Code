#include <bits/stdc++.h>
using namespace std;
const int _ = 2505;
int f[_], a[_];
int main()
{
    // f[i] 表示前 i 个人需要多少件宿舍
    // 终极答案为 f[n]
    freopen("fan.in", "r", stdin);
    freopen("fan.out", "w", stdout);
    int n, m;
    // 我居然会写dp题了ohhhhhhh
    /*XYC YYDS*/
    /*cookiebus YYDS
    /*nullptr YYDS*/
    /*tree_one_ YYDS*/
    /*PinkRabbit YYDS*/
    /*Eternity YYDS*/
    /*yuxinhao YYDS*/
    /*_ YYDS*/
    cin >> n >> m;
    for (int i = 1; i <= n; i++)
    {
        cin >> a[i]; // 读入
    }
    int tmp = 0;
    f[1] = 1;
    for (int i = 2; i <= n; i++)
    {
        if (a[i] == a[i - 1])
            f[i] = f[i - 1], tmp++;
        else if (a[i] != a[i - 1])
        {
            int cur = a[i];
            // int t = tmp;
            int j;
            // int flag = 0;
            // 混搭是可以不连续的呜呜呜（不懂怎么写qwq）
            for (j = i; j <= tmp + i; j++)
            {
                if (a[j] == cur)
                    f[i] = f[i - 1];
                else
                    break;
            }
            f[j] = f[j - 1] + 1; // 其他新的宿舍
            i++;
            // tmp = t;
        }
    }
    cout << f[n];
    return 0;
}