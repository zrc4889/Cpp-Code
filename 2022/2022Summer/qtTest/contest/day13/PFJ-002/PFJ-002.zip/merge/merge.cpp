#include <bits/stdc++.h>
using namespace std;
cosnt int _ = 114514;
int a[_];
int main()
{
    // #ifdef LOCAL
    //     LOCALfo
    // #endif
    freopen("merge.in", "r", stdin);
    freopen("merge.out", "w", stdout);
    int n;
    cin >> n;
    for (int i = 1; i <= n; i++)
    {
        cin >> a[i];
    }
    
    return 0;
}