#include <bits/stdc++.h>
using namespace std;

int main()
{
    // #ifdef LOCAL
    // LOCALfo
    // #endif
    // freopen("angle.in", "r", stdin);
    // freopen("angle.out", "w", stdout);
    int x;
    double y;
    cin >> x >> y;
    double ans = 0;
    ans += (x % 12) * 30;
    // 加上没有偏移的情况
    ans -= y * 6;
    // 减去分针
    ans += (y / 60) * 30;
    printf("%.1f", abs(ans));
    return 0;
}