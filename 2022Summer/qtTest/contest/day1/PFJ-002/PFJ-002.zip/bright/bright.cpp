#include <bits/stdc++.h>
using namespace std;
const int _ = 105;
int main()
{
    freopen("bright.in", "r", stdin);
    freopen("bright.out", "w", stdout);
    int n, k;
    // 区间 dp
    cin >> n >> k;
    for (int i = 1; i <= n; i++)
        cin >> a[i];
    for (int i = 1; i <= n; i++)
    {
        for (int j = i + 1; j <= n; j += k)
    }
    return 0;
}