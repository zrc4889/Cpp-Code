#include <bits/stdc++.h>
using namespace std;
// dp
const int _ = 205;
int n, m;
// int f[_][_];
int a[_], b[_];
void dfs(int x, int y)
{

}
int main()
{
    cin >> n >> m;
    for (int i = 1; i <= m; i++)
    {
        cin >> a[i] >> b[i];
    }
    
    return 0;
}