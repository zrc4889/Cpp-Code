// 17 位 或 18 位

#include <bits/stdc++.h>
using namespace std;

int main()
{
    
    return 0;
}