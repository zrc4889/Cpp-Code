#include <bits/stdc++.h>
#define int long long
using namespace std;
int a[1145149];
int XOROperator(int &a, int &b)
{
    return a ^ b;
}
signed main()
{
    // 3^5 即 0000 0011 ^ 0000 0101 = 0000 0111  因此，3|5的值得6
    // int a = 3, b = 5;
    freopen("xor.in", "r", stdin);
    freopen("xor.out", "w", stdout);
    int n;
    int ans = 0;
    cin >> n;
    for (int i = 1; i <= n; i++)
        cin >> a[i];
    for (int i = 1; i <= n; i++)
    {
        for (int j = i; j <= n; j++)
        {
            ans += XOROperator(a[i], a[j]);
        }
    }
    cout << ans << endl;
    return 0;
}