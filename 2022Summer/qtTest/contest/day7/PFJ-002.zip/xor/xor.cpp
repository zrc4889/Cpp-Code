#include <bits/stdc++.h>
#define int long long
using namespace std;
int k, q;
int l, r;
const int _ = 1e5;
int a[_];
void xorr(int l, int r)
{
    int ans = a[l];
    for (int i = l + 1; i <= r; i++)
    {
        ans ^= a[i];
    }
    cout << ans << endl;
}
signed main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    freopen("xor.in", "r", stdin);
    freopen("xor.out", "w", stdout);
    // #ifdef LOCAL
    //     LOCALfo
    // #endif
    cin >> k;
    for (int i = 1; i <= k; i++)
        cin >> a[i];
    cin >> q;
    for (int i = 1; i <= q; i++)
    {
        cin >> l >> r;
        xorr(l, r);
    }
    return 0;
}